# import flask related
from flask import Flask, request, abort, send_file
# import linebot related
from linebot import (
    LineBotApi, WebhookHandler
)
from linebot.exceptions import (
    InvalidSignatureError
)
from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage, ImageMessage,
    LocationSendMessage, ImageSendMessage, StickerSendMessage
)
import os
import random
import string

from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import TextOperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials
import azure.cognitiveservices.speech as speechsdk
import time

# create flask server
app = Flask(__name__)
# your linebot message API - Channel access token (from LINE Developer)
line_bot_api = LineBotApi('7oIBiys2y2yuJ80Y2WsE//jRwOUfxsn2cECmOPq/DtgD41BPfte4yh94Xx4KpzSnWcI5QMN8bopscc+WFQhd6f6bi+OrMl5JiR1RZTo1ejpNUP/QyWyHPXFD7cItytCGdRmATbuyrGh5AUXN4uQZtgdB04t89/1O/w1cDnyilFU=')
# your linebot message API - Channel secret
handler = WebhookHandler('93c2be581cd4a01f6637e5c6b4739c06')


@app.route("/callback", methods=['POST'])
def callback():
    # get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']

    # get request body as text
    body = request.get_data(as_text=True)
    app.logger.info("Request body: " + body)

    # handle webhook body
    try:
        print('receive msg')
        handler.handle(body, signature)
    except InvalidSignatureError:
        print("Invalid signature. Please check your channel access token/channel secret.")
        abort(400)
    return 'OK'

# handle msg
@handler.add(MessageEvent, message=ImageMessage)
def handle_image(event):
    line_bot_api.reply_message(event.reply_token,TextSendMessage(text='稍等一下'))
    image_name = '000.jpg'
    image_content = line_bot_api.get_message_content(event.message.id)
    path='./images/'+image_name
    with open(path, 'wb') as fd:
        for chunk in image_content.iter_content():
            fd.write(chunk)
    callAzure(path)

@app.route("/images/<path:filename>", methods=['GET'])
def images(filename):
    try:
        src = os.getcwd()+'/images/'+filename
        return send_file(src, mimetype='image/jpg')
    except IOError as ex:
        return str(ex)

def callAzure(apiUrl):
    # Set API key.
    subscription_key = '08308402ee9a41cfadadced5d9b7d53e'
    # Set endpoint.
    endpoint = 'https://xxxxx.cognitiveservices.azure.com/'
    # Call API
    computervision_client = ComputerVisionClient(endpoint, CognitiveServicesCredentials(subscription_key))

    '''
    Batch Read File, recognize printed text - remote
    This example will extract printed text in an image, then print results, line by line.
    This API call can also recognize handwriting (not shown).
    '''
    print("===== Batch Read File - remote =====")
    # Get an image with printed text
    remote_image_printed_text_url = "https://9a9ca30b03e7.ngrok.io/"+apiUrl

    # Call API with URL and raw response (allows you to get the operation location)
    recognize_printed_results = computervision_client.batch_read_file(remote_image_printed_text_url,  raw=True)

    # Get the operation location (URL with an ID at the end) from the response
    operation_location_remote = recognize_printed_results.headers["Operation-Location"]
    # Grab the ID from the URL
    operation_id = operation_location_remote.split("/")[-1]

    # Call the "GET" API and wait for it to retrieve the results 
    while True:
        get_printed_text_results = computervision_client.get_read_operation_result(operation_id)
        if get_printed_text_results.status not in ['NotStarted', 'Running']:
            break
        time.sleep(1)

    # Print the detected text, line by line
    if get_printed_text_results.status == TextOperationStatusCodes.succeeded:
        for text_result in get_printed_text_results.recognition_results:
            for line in text_result.lines:
                # Creates an instance of a speech config with specified subscription key and service region.
                # Replace with your own subscription key and service region (e.g., "westus").
                speech_key, service_region = "f2ea6b388e3647e8a9aad91164ad3e8a", "southcentralus"
                speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)

                # Creates a speech synthesizer using the default speaker as audio output.
                speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

                # Receives a text from console input.
                #print("Type some text that you want to speak...")
                text = line.text
                # Synthesizes the received text to speech.
                # The synthesized speech is expected to be heard on the speaker with this line executed.
                result = speech_synthesizer.speak_text_async(text).get()

                # Checks result.
                if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                    print("Speech synthesized to speaker for text [{}]".format(text))
                elif result.reason == speechsdk.ResultReason.Canceled:
                    cancellation_details = result.cancellation_details
                    print("Speech synthesis canceled: {}".format(cancellation_details.reason))
                    if cancellation_details.reason == speechsdk.CancellationReason.Error:
                        if cancellation_details.error_details:
                            print("Error details: {}".format(cancellation_details.error_details))
                    print("Did you update the subscription info?")

# run app
if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000)