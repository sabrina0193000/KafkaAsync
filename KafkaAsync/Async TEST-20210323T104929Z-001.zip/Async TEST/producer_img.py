import os
import time

import asyncio

import numpy as np
import cv2
from confluent_kafka import Producer
import sys

PIC_FOLDER = './record/'
DETECT_CYCLE = 5    # 1 face detect call per 3 sec
FPS = 40            # 40 frame per second
dltT = 1/FPS        # deltaT: 0.025s per frame

def error_cb(err):
    print('Error: %s' % err)

def kafka_producer(url_name):
# 主程式進入點
    url = url_name
        # 步驟1. 設定要連線到Kafka集群的相關設定
    props = {
        # Kafka集群在那裡?
        'bootstrap.servers': '10.2.1.240:9092',  # <-- 置換成要連接的Kafka集群
        'error_cb': error_cb                    # 設定接收error訊息的callback函數
    }
    # 步驟2. 產生一個Kafka的Producer的實例
    producer = Producer(props)
    # 步驟3. 指定想要發佈訊息的topic名稱
    topicName = 'url'
    msgCounter = 0
    try:
        # produce(topic, [value], [key], [partition], [on_delivery], [timestamp], [eaders])
        producer.produce(topicName, url)
        producer.flush()
        msgCounter += 4
        print('Send ' + str(msgCounter) + ' messages to Kafka')
    except BufferError as e:
        # 錯誤處理
        sys.stderr.write('%% Local producer queue is full ({} messages awaiting delivery): try again\n'
                         .format(len(producer)))
    except Exception as e:
        print(e)
    # 步驟5. 確認所在Buffer的訊息都己經送出去給Kafka了
    producer.flush()


async def main():

    cap = cv2.VideoCapture(0)
    tmLastSave = time.time()

    while(True):
        tmLpStart = time.time()
        ret, save_img = cap.read()

        if ret == True:
            cv2.imshow("image", save_img)
            if DETECT_CYCLE - (time.time() - tmLastSave) <= 0:
                tmLastSave = time.time()
                print(f'SAVE: {tmLastSave}', end=' ')
                name = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime()) + '.jpg'
                fName = PIC_FOLDER + name
                url_name = "https://9d2588b8478c.ngrok.io/record/" + name
                if cv2.imwrite(fName, save_img):
                    print(fName)
                    kafka_producer(url_name)


        key = cv2.waitKey(1)    # 延遲一毫秒，並取得按鍵
        if key & 0xFF == ord('q'):
            print("disable camera")
            break
        dts = dltT - (time.time() - tmLpStart)
        if dts > 0:
            await asyncio.sleep(dts)

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__" :
    if not os.path.exists(PIC_FOLDER):
        os.makedirs(PIC_FOLDER, exist_ok=True)
    asyncio.run(main())

