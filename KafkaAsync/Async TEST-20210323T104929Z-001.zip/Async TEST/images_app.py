from flask import Flask, request, abort, send_file
import os

app = Flask(__name__)

@app.route("/record/<path:filename>", methods=['GET'])
def images(filename):
    try:
        src = os.getcwd()+'/record/'+filename
        return send_file(src, mimetype='image/jpg')
    except IOError as ex:
        return str(ex)


# run app
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)